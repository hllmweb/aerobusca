-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Máquina: localhost:3306
-- Data de Criação: 10-Mar-2017 às 13:01
-- Versão do servidor: 5.6.35
-- versão do PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `aerobusc_web`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `aeronaves`
--

CREATE TABLE IF NOT EXISTS `aeronaves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `fabricante` varchar(255) NOT NULL,
  `modelo` varchar(255) NOT NULL,
  `categoria` varchar(255) NOT NULL,
  `prefixo` varchar(255) NOT NULL,
  `ano` int(11) NOT NULL,
  `passageiros` int(11) NOT NULL,
  `peso_bagagem` varchar(255) NOT NULL,
  `velocidade` float NOT NULL,
  `autonomia` float NOT NULL,
  `operacao` varchar(255) NOT NULL,
  `base_operacao` varchar(255) NOT NULL,
  `latitude` varchar(255) NOT NULL,
  `longitude` varchar(255) NOT NULL,
  `tipo_servicos` varchar(255) NOT NULL,
  `valor` double NOT NULL,
  `valor_pernoite` double NOT NULL,
  `imagens` text NOT NULL,
  `status` int(11) NOT NULL COMMENT '0=ativo; 1=inativo',
  `servico_bordo` varchar(255) NOT NULL,
  `banheiro` varchar(255) NOT NULL,
  `visao_geral` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Extraindo dados da tabela `aeronaves`
--

INSERT INTO `aeronaves` (`id`, `id_usuario`, `fabricante`, `modelo`, `categoria`, `prefixo`, `ano`, `passageiros`, `peso_bagagem`, `velocidade`, `autonomia`, `operacao`, `base_operacao`, `latitude`, `longitude`, `tipo_servicos`, `valor`, `valor_pernoite`, `imagens`, `status`, `servico_bordo`, `banheiro`, `visao_geral`) VALUES
(17, 48, 'Cessna', 'Sertanejo', 'Mono Motor', 'PT-EFI', 2000, 5, '120', 260, 5, 'VFR,IFR', 'Manaus - AM, Brasil', '-3.1190275', '-60.02173140000002', 'Passageiros,Carga,Remoção Aérea', 1500, 500, '{\n    "imagem1": "4414857459207352.jpg",\n    "imagem2": "614857459306859.png",\n    "imagem3": "",\n    "imagem4": ""\n}', 0, 'Simples', 'Parcial', '<p>Informa&ccedil;&otilde;es da aeronave.</p>'),
(16, 48, 'Embraer', 'Seneca', 'Bimotor', 'PT-DMN', 2000, 5, '120', 260, 5, 'VFR,IFR', 'Manaus - AM, Brasil', '-3.1190275', '-60.02173140000002', 'Passageiros,Carga,Remoção Aérea', 1800, 500, '{\n    "imagem1": "4214857458321308.jpg",\n    "imagem2": "3314857458362773.jpg",\n    "imagem3": "",\n    "imagem4": ""\n}', 0, 'Simples', 'Parcial', '<p>Informa&ccedil;&otilde;es relacionada a essa aeronave.</p>'),
(14, 32, 'Cessna', 'Caraj', 'Turboélice', 'PT-MZM', 1111, 9, '180', 360, 4.5, 'VFR,IFR', 'Manaus - AM, Brasil', '-3.1190275', '-60.02173140000002', 'Passageiros,Carga', 3000, 500, '{\n    "imagem1": "3614857402601142.jpg",\n    "imagem2": "181485740265327.jpg",\n    "imagem3": "",\n    "imagem4": ""\n}', 0, 'Simples', 'Parcial', '<p>1</p>'),
(13, 26, 'Piper', 'Meridian', 'Turboélice', 'PT-XZA', 2010, 4, '150', 400, 5, 'VFR,IFR', 'Manaus - AM, Brasil', '-3.1190275', '-60.02173140000002', 'Passageiros', 3000, 1, '{\n    "imagem1": "6314856290046700.png",\n    "imagem2": "6914856290146461.png",\n    "imagem3": "3714856290228974.png",\n    "imagem4": ""\n}', 0, 'Simples', 'Parcial', '<p>a</p>'),
(12, 23, 'Cessna', 'Caravan', 'Turboélice', 'PP-AMT', 2001, 9, '600', 280, 6, 'VFR,IFR', 'Manaus - AM, Brasil', '-3.1190275', '-60.02173140000002', 'Passageiros,Carga', 2500, 500, '{\n    "imagem1": "5014853960963309.jpg",\n    "imagem2": "7014853961034567.jpg",\n    "imagem3": "",\n    "imagem4": ""\n}', 1, 'Simples', 'Parcial', '<p>&Oacute;TIMA AERONAVE, EXTREMAMENTE CONFIAVEL.&nbsp;<span style="color: #545454; font-family: arial, sans-serif; font-size: small;">Um&nbsp;</span><span style="font-weight: bold; color: #6a6a6a; font-family: arial, sans-serif; font-size: small;">avi&atilde;o</span><span style="color: #545454; font-family: arial, sans-serif; font-size: small;">&nbsp;ou aeroplano &eacute; qualquer aeronave que necessita de asas fixas e motores para se ..... Este</span><span style="font-weight: bold; color: #6a6a6a; font-family: arial, sans-serif; font-size: small;">texto</span><span style="color: #545454; font-family: arial, sans-serif; font-size: small;">&nbsp;&eacute; disponibilizado nos termos da licen&ccedil;a Creative Commons - Atribui&ccedil;&atilde;o</span></p>'),
(11, 21, 'Embraer', 'Bandeirante', 'Turboélice', 'PT-GKX', 1989, 14, '240', 330, 5, 'VFR', 'Manaus - AM, Brasil', '-3.1190275', '-60.02173140000002', 'Passageiros,Carga', 4000, 800, '{\n    "imagem1": "3814852970891607.jpg",\n    "imagem2": "",\n    "imagem3": "",\n    "imagem4": ""\n}', 0, 'Simples', 'Parcial', '<p>&oacute;tima empresa</p>');

-- --------------------------------------------------------

--
-- Estrutura da tabela `carrinho`
--

CREATE TABLE IF NOT EXISTS `carrinho` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_aeronave` int(11) NOT NULL,
  `token` varchar(255) COLLATE utf8_bin NOT NULL,
  `localizacoes` text COLLATE utf8_bin NOT NULL,
  `dias_pernoite` int(11) NOT NULL,
  `id_taxiaereo` int(11) NOT NULL,
  `valor_pernoite` double NOT NULL,
  `distancia_total` double NOT NULL,
  `tempo_estimado_ida` varchar(20) COLLATE utf8_bin NOT NULL,
  `tempo_estimado_total` varchar(20) COLLATE utf8_bin NOT NULL,
  `categoria_voo` varchar(255) COLLATE utf8_bin NOT NULL,
  `valor` double NOT NULL,
  `status` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT 'aberto',
  `data` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=42 ;

--
-- Extraindo dados da tabela `carrinho`
--

INSERT INTO `carrinho` (`id`, `id_usuario`, `id_aeronave`, `token`, `localizacoes`, `dias_pernoite`, `id_taxiaereo`, `valor_pernoite`, `distancia_total`, `tempo_estimado_ida`, `tempo_estimado_total`, `categoria_voo`, `valor`, `status`, `data`) VALUES
(41, 24, 14, 'KIMCID', '{\n    "cat_voo": "passageiros",\n    "cat_aeronave1": "turboelice",\n    "cat_aeronave": "turboelice",\n    "count": [\n        "ok"\n    ],\n    "origem": [\n        "Manaus - AM, Brasil"\n    ],\n    "origem_local_lat": [\n        "-3.1190275"\n    ],\n    "origem_local_lng": [\n        "-60.02173140000002"\n    ],\n    "destino": [\n        "Bel\\u00e9m - PA, Brasil"\n    ],\n    "destino_local_lat": [\n        "-1.4557549"\n    ],\n    "destino_local_lng": [\n        "-48.49017989999999"\n    ],\n    "data_ida": [\n        "25\\/02\\/2017"\n    ],\n    "hora_ida": [\n        "12:12"\n    ],\n    "data_volta": [\n        "28\\/02\\/2017"\n    ],\n    "hora_volta": [\n        "12:12"\n    ],\n    "passageiros": [\n        "1"\n    ]\n}', 3, 32, 1500, 1295.91, '03:35', '07:11', 'passageiros', 21598.5, 'aberto', '1487898424'),
(40, 21, 11, 'YE6ZIC', '{\n    "cat_voo": "passageiros",\n    "cat_aeronave1": "turboelice",\n    "cat_aeronave": "turboelice",\n    "count": [\n        "ok"\n    ],\n    "origem": [\n        "Manaus - AM, Brasil"\n    ],\n    "origem_local_lat": [\n        "-3.1190275"\n    ],\n    "origem_local_lng": [\n        "-60.02173140000002"\n    ],\n    "destino": [\n        "Santar\\u00e9m - PA, Brasil"\n    ],\n    "destino_local_lat": [\n        "-2.4506291"\n    ],\n    "destino_local_lng": [\n        "-54.7009228"\n    ],\n    "data_ida": [\n        "27\\/01\\/2017"\n    ],\n    "hora_ida": [\n        "12:00"\n    ],\n    "data_volta": [\n        "29\\/01\\/2017"\n    ],\n    "hora_volta": [\n        "01:00"\n    ],\n    "passageiros": [\n        "1"\n    ]\n}', 2, 21, 1600, 596.27, '01:48', '03:36', 'passageiros', 14454.96, 'fechado', '1485481416'),
(39, 21, 12, 'YE6ZIC', '{\n    "cat_voo": "passageiros",\n    "cat_aeronave1": "turboelice",\n    "cat_aeronave": "turboelice",\n    "count": [\n        "ok"\n    ],\n    "origem": [\n        "Manaus - AM, Brasil"\n    ],\n    "origem_local_lat": [\n        "-3.1190275"\n    ],\n    "origem_local_lng": [\n        "-60.02173140000002"\n    ],\n    "destino": [\n        "Santar\\u00e9m - PA, Brasil"\n    ],\n    "destino_local_lat": [\n        "-2.4506291"\n    ],\n    "destino_local_lng": [\n        "-54.7009228"\n    ],\n    "data_ida": [\n        "27\\/01\\/2017"\n    ],\n    "hora_ida": [\n        "12:00"\n    ],\n    "data_volta": [\n        "29\\/01\\/2017"\n    ],\n    "hora_volta": [\n        "01:00"\n    ],\n    "passageiros": [\n        "1"\n    ]\n}', 2, 23, 1000, 596.27, '02:07', '04:15', 'passageiros', 10647.62, 'fechado', '1485481402');

-- --------------------------------------------------------

--
-- Estrutura da tabela `categorias`
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_categoria` varchar(255) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10 ;

--
-- Extraindo dados da tabela `categorias`
--

INSERT INTO `categorias` (`id`, `nome_categoria`) VALUES
(1, 'Turboélice'),
(2, 'Bimotor'),
(3, 'Jato'),
(4, 'Mono Motor'),
(5, 'Mono Motor Pistão'),
(7, 'Bimotor Pistão');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cotacoes`
--

CREATE TABLE IF NOT EXISTS `cotacoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) COLLATE utf8_bin NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_taxiaereo` int(11) NOT NULL,
  `id_aeronave` int(11) NOT NULL,
  `localizacoes` text COLLATE utf8_bin NOT NULL,
  `categoria_voo` varchar(255) COLLATE utf8_bin NOT NULL,
  `dias_pernoite` int(11) NOT NULL,
  `valor_pernoite` int(11) NOT NULL,
  `tempo_estimado_ida` varchar(20) COLLATE utf8_bin NOT NULL,
  `tempo_estimado_total` varchar(20) COLLATE utf8_bin NOT NULL,
  `custo_estimado` double NOT NULL,
  `distancia_total` double NOT NULL,
  `descricao` text COLLATE utf8_bin NOT NULL,
  `meio_pagamento` varchar(255) COLLATE utf8_bin NOT NULL,
  `status_cotacao` varchar(255) COLLATE utf8_bin NOT NULL,
  `status_envio` varchar(255) COLLATE utf8_bin NOT NULL,
  `nome_admin` varchar(255) COLLATE utf8_bin NOT NULL,
  `data_registro` varchar(255) COLLATE utf8_bin NOT NULL,
  `valor` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `cotacoes`
--

INSERT INTO `cotacoes` (`id`, `token`, `id_cliente`, `id_taxiaereo`, `id_aeronave`, `localizacoes`, `categoria_voo`, `dias_pernoite`, `valor_pernoite`, `tempo_estimado_ida`, `tempo_estimado_total`, `custo_estimado`, `distancia_total`, `descricao`, `meio_pagamento`, `status_cotacao`, `status_envio`, `nome_admin`, `data_registro`, `valor`) VALUES
(13, 'YE6ZIC', 21, 23, 12, '{\n    "cat_voo": "passageiros",\n    "cat_aeronave1": "turboelice",\n    "cat_aeronave": "turboelice",\n    "count": [\n        "ok"\n    ],\n    "origem": [\n        "Manaus - AM, Brasil"\n    ],\n    "origem_local_lat": [\n        "-3.1190275"\n    ],\n    "origem_local_lng": [\n        "-60.02173140000002"\n    ],\n    "destino": [\n        "Santar\\u00e9m - PA, Brasil"\n    ],\n    "destino_local_lat": [\n        "-2.4506291"\n    ],\n    "destino_local_lng": [\n        "-54.7009228"\n    ],\n    "data_ida": [\n        "27\\/01\\/2017"\n    ],\n    "hora_ida": [\n        "12:00"\n    ],\n    "data_volta": [\n        "29\\/01\\/2017"\n    ],\n    "hora_volta": [\n        "01:00"\n    ],\n    "passageiros": [\n        "1"\n    ]\n}', 'passageiros', 2, 1000, '02:07', '04:15', 10647.62, 596.27, '', '', 'pendente', 'pendente', '', '1485481420', 10647.6),
(12, 'YE6ZIC', 21, 21, 11, '{\n    "cat_voo": "passageiros",\n    "cat_aeronave1": "turboelice",\n    "cat_aeronave": "turboelice",\n    "count": [\n        "ok"\n    ],\n    "origem": [\n        "Manaus - AM, Brasil"\n    ],\n    "origem_local_lat": [\n        "-3.1190275"\n    ],\n    "origem_local_lng": [\n        "-60.02173140000002"\n    ],\n    "destino": [\n        "Santar\\u00e9m - PA, Brasil"\n    ],\n    "destino_local_lat": [\n        "-2.4506291"\n    ],\n    "destino_local_lng": [\n        "-54.7009228"\n    ],\n    "data_ida": [\n        "27\\/01\\/2017"\n    ],\n    "hora_ida": [\n        "12:00"\n    ],\n    "data_volta": [\n        "29\\/01\\/2017"\n    ],\n    "hora_volta": [\n        "01:00"\n    ],\n    "passageiros": [\n        "1"\n    ]\n}', 'passageiros', 2, 1600, '01:48', '03:36', 14454.96, 596.27, '', '', 'pendente', 'pendente', '', '1485481420', 14455);

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensagens`
--

CREATE TABLE IF NOT EXISTS `mensagens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cotacao` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_taxiaereo` int(11) NOT NULL,
  `tipo_usuario` varchar(255) COLLATE utf8_bin NOT NULL,
  `texto` text COLLATE utf8_bin NOT NULL,
  `data` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `mensagens`
--

INSERT INTO `mensagens` (`id`, `id_cotacao`, `id_cliente`, `id_taxiaereo`, `tipo_usuario`, `texto`, `data`) VALUES
(1, 5, 17, 17, 'cliente', '<p>Oi gostaria de saber se posso levar meu gato</p>', '1484935400'),
(2, 5, 17, 15, 'taxiaereo', '<p>Sim, voc&ecirc; pode levar seu gato. possui gaiola ?</p>', '1484935461'),
(3, 5, 17, 17, 'cliente', '<p>dada</p>', '1484935501');

-- --------------------------------------------------------

--
-- Estrutura da tabela `modelos`
--

CREATE TABLE IF NOT EXISTS `modelos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fabricante` varchar(255) NOT NULL,
  `modelo` varchar(255) NOT NULL,
  `categoria` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Extraindo dados da tabela `modelos`
--

INSERT INTO `modelos` (`id`, `fabricante`, `modelo`, `categoria`) VALUES
(1, 'Cessna', 'Cessna 152', 'Instrução de Vôo'),
(2, 'Cessna', 'Caravan', 'Turboélice'),
(16, 'Embraer', 'Bandeirante', 'Turboélice'),
(26, 'Cessna', 'Caraj', 'Turboélice'),
(18, 'C. A. Paulista', 'CP4', 'Mono Motor'),
(19, 'C. A. Paulista', 'CP4\n\n', 'Mono Motor Pistão'),
(25, 'Embraer', 'Caraj', 'Turboélice'),
(21, 'Beechcraft', 'Baron 58', 'Bimotor Pistão'),
(22, 'Beechcraft', 'Baron 55', 'Bimotor Pistão'),
(23, 'Beechcraft', 'Bonanza', 'Mono Motor Pistão'),
(24, 'Beechcraft', 'Sierra', 'Mono Motor Pistão'),
(27, 'Embraer', 'Brasilia', 'Turboélice'),
(28, 'Piper', 'Meridian', 'Turboélice'),
(29, 'Embraer', 'Seneca', 'Bimotor'),
(30, 'Cessna', 'Sertanejo', 'Mono Motor');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_usuario` varchar(50) COLLATE utf8_bin NOT NULL,
  `nivel_cadastro` int(11) NOT NULL COMMENT '1=Fez cadastro obrigatório; 2=Inseriu informações adicionais; 3=Adicionou aeronaves; 4=Cadastro Completo',
  `nome` varchar(255) COLLATE utf8_bin NOT NULL,
  `sobrenome` varchar(255) COLLATE utf8_bin NOT NULL,
  `data_nascimento` varchar(255) COLLATE utf8_bin NOT NULL,
  `sexo` varchar(3) COLLATE utf8_bin NOT NULL,
  `cpf_ou_cnpj` varchar(255) COLLATE utf8_bin NOT NULL,
  `telefone` varchar(255) COLLATE utf8_bin NOT NULL,
  `pais` varchar(255) COLLATE utf8_bin NOT NULL,
  `cep` varchar(255) COLLATE utf8_bin NOT NULL,
  `estado` varchar(255) COLLATE utf8_bin NOT NULL,
  `cidade` varchar(255) COLLATE utf8_bin NOT NULL,
  `bairro` varchar(255) COLLATE utf8_bin NOT NULL,
  `rua` varchar(255) COLLATE utf8_bin NOT NULL,
  `numero_endereco` varchar(50) COLLATE utf8_bin NOT NULL,
  `gestor_responsavel` varchar(255) COLLATE utf8_bin NOT NULL,
  `banco` varchar(255) COLLATE utf8_bin NOT NULL,
  `agencia` varchar(255) COLLATE utf8_bin NOT NULL,
  `tipo_conta` varchar(3) COLLATE utf8_bin NOT NULL,
  `n_conta` varchar(255) COLLATE utf8_bin NOT NULL,
  `metodos_pagamento` varchar(255) COLLATE utf8_bin NOT NULL,
  `cheta` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `senha` varchar(255) COLLATE utf8_bin NOT NULL,
  `descricao_empresa` text COLLATE utf8_bin NOT NULL,
  `token` varchar(255) COLLATE utf8_bin NOT NULL,
  `verificado` int(11) NOT NULL DEFAULT '0' COMMENT '0=Não verificado; 1=Verificado;',
  `imagem` varchar(255) COLLATE utf8_bin NOT NULL,
  `data_registro` varchar(255) COLLATE utf8_bin NOT NULL,
  `ip` varchar(255) COLLATE utf8_bin NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '1=Ativo; 2=Banido;',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=51 ;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `tipo_usuario`, `nivel_cadastro`, `nome`, `sobrenome`, `data_nascimento`, `sexo`, `cpf_ou_cnpj`, `telefone`, `pais`, `cep`, `estado`, `cidade`, `bairro`, `rua`, `numero_endereco`, `gestor_responsavel`, `banco`, `agencia`, `tipo_conta`, `n_conta`, `metodos_pagamento`, `cheta`, `email`, `senha`, `descricao_empresa`, `token`, `verificado`, `imagem`, `data_registro`, `ip`, `status`) VALUES
(1, 'admin', 1, 'Hugo', 'Mesquita', '05/11/1998', 'm', '03784722245', '92991278199', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'admin@aerobusca.com', 'e75cc8677ae7a6a02473f60dcd3ffbfb', 'O AEROBUSCA tem sempre uma solução para o seu problema de transporte aéreo. Seja qual for o destino, ela está equipada com aeronaves modernas e sempre em perfeitas condições. Para isso, conta em sua frota de equipamentos anfibios, capazes de pousar nos rios da Amazônia, a modernos jatos, com autonomia para atingir qualquer pontos do País. Desta forma apresentamos nosso valor para a realização deste voo conforme sua solicitação.', '0f7f876446f0c7d83087457e547600af', 0, '5714847516614144.jpg', '1480977485', '127.0.0.1', 1),
(26, 'taxiaereo', 2, 'CTA Taxi Aereo', '', '', '', '01341740000154', '(00) 00000-0000', '', '11111-111', 'AM', 'MANAUS', '1', '1', '1', 'cleiton', '', '', '', '', 'Cartão', '11111111111111111111111111111111111111111111', 'cta@gmail.com', 'e75cc8677ae7a6a02473f60dcd3ffbfb', 'a', '3f037231de3c88e37afc41c9e8e7a7dc', 0, '', '1485628847', '191.189.9.201', 1),
(23, 'taxiaereo', 2, 'Amazonaves  ', '', '', 'm', '00000000000000', '(00) 00000-0000', 'Brasil', '00000-000', 'AM', 'manaus', '0', '0', '0', 'Geraldo', '', '', 'Sel', '', 'null', '', 'amazonaves@gmail.com', 'e75cc8677ae7a6a02473f60dcd3ffbfb', '<p>A</p>', 'a661d7c9930e9c043b7671345bf8af60', 0, '', '1485194730', '191.189.13.201', 1),
(24, 'cliente', 1, 'Germano Baptista', 'baptista', '171176', 'm', '49293273268', '(00) 00000-0000', 'Brasil', '', '', '', '', '', '', '', '', '', 'Sel', '', 'null', '', 'germano@gmail.com', 'e75cc8677ae7a6a02473f60dcd3ffbfb', '', 'e94c5bf09d701ef872178dd044c88c44', 0, '', '1485398506', '191.189.13.201', 1),
(17, 'cliente', 1, 'Luis', 'Mesquita', '26/08/1990', 'm', '00425005240', '(92) 98184-7654', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'cliente@aerobusca.com', 'e75cc8677ae7a6a02473f60dcd3ffbfb', '', 'ec99979386018e2babf0c7882bdb217d', 0, '', '1484768927', '201.75.56.113', 1),
(48, 'taxiaereo', 2, 'Tio Taxi Aéreo ', '', '', '---', '01341740000154', '(22) 22222-2222', 'Brasil', '11111-111', 'AM', 'MANAUS', '1', '1', '1', 'Moreno', '', '', 'Sel', '', 'null', '', 'tio@gmail.com', 'e75cc8677ae7a6a02473f60dcd3ffbfb', '<p>a</p>', '03cebc44284edc74dec630ceb85f120d', 0, '', '1485745719', '191.189.9.201', 1),
(32, 'taxiaereo', 2, 'Marivan ', '', '', '---', '01341740000154', '(00) 00000-0000', 'Brasil', '22222-222', 'AM', 'MANAUS', '2', '2', '2', 'Mario ivan', '', '', 'Sel', '', 'null', '', 'marivan@gmail.com', 'e75cc8677ae7a6a02473f60dcd3ffbfb', '<p>2</p>', '6556cb6611aecac2d279c0a17f6dc6d2', 0, '', '1485740192', '191.189.9.201', 1),
(22, 'taxiaereo', 2, 'Rico Taxi Aereo', '', '', '', '00000000000000', '(00) 00000-0000', '', '00000-000', 'AM', 'manaus', '0', '0', '0', 'atil', '', '', '', '', 'Todos selecionados', '11111111111111111', 'rico@gmail.com', 'e75cc8677ae7a6a02473f60dcd3ffbfb', 'rica, com muitos anos de atuação', '52223becf7d8db02dd2b7b02ffb61ae1', 0, '', '1485140162', '191.189.13.201', 1),
(21, 'taxiaereo', 2, 'Apui taxi aereo', '', '', '', '00000000000000', '(99) 99999-9999', '', '00000-000', 'AM', 'manaus', '0', '0', '0', 'germano', '', '', '', '', 'Cartão', '00000000', 'apui@gmail.com', 'e75cc8677ae7a6a02473f60dcd3ffbfb', 'Empresa maravilhosa', '0a1e35e4ff265df58dc3642b97dd3a26', 0, '', '1485138606', '191.189.13.201', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
